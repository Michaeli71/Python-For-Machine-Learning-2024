def repeat_chars(input):
    result = ""

    # TODO

    return result


print(repeat_chars("ABCD"))
print(repeat_chars("ABCDEF"))