def is_anagram(str1, str2):
    # TODO
    pass


print(is_anagram("Ampel", "Lampe"))
print(is_anagram("Ampel", "Palme"))
print(is_anagram("Palme", "Lampe"))