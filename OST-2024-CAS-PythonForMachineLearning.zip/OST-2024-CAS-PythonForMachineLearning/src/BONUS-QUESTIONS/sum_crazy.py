values = [1, 2, "FAIL", "3", 4, 5, "SEVEN"]

# TypeError: unsupported operand type(s) for +: 'int' and 'str'
print(sum(values))