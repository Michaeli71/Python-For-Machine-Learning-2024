age = 72

if 17 < age < 65:
    print("you have to learn python")
else:
    print("learn lego")

width = 100
if 0 <= width < 1000:
   pass