import min_example


def main():
    print(min_example.min_of_3(72, 71, 42))


if __name__ == "__main__":
    main()