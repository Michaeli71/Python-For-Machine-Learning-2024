sample_names = ["TIM", "TOM", "MIKE", "JOHN", "MICHAEL", "STEFAN"]


def choose_greeting():
    # TODO
    pass


greet_double_named = "" # TODO
print(greet_double_named)

